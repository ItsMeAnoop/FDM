package com.field.datamatics.eventbus;

/**
 * Created by USER on 12/28/2015.
 */
public class AreaCoverageEvent {
    public final String message;

    public AreaCoverageEvent(String message) {
        this.message = message;
    }
}
