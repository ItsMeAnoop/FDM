package com.field.datamatics.models;

/**
 * Created by Jith on 10/21/2015.
 */
public class MediaItem {
    public String path;
    public String name;
}
