package com.field.datamatics.interfaces;

/**
 * Created by USER on 11/14/2015.
 */
public interface OperationCallBacks {
    public void onSuccess();
    public void onError();
}
