package com.field.datamatics.interfaces;

/**
 * Created by Jithz on 12/20/2015.
 */
public interface ItemSelectedListener {
    void onItemSelected(int value);
}
