package com.field.datamatics.interfaces;

/**
 * Created by USER on 12/15/2015.
 */
public interface DialogCallBacks {
    public void onOk();
    //public void onCancel();
}
