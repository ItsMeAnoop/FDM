package com.field.datamatics.eventbus;

/**
 * Created by Jithz on 12/12/2015.
 */
public class PerformanceChartEvent {
    public final String message;

    public PerformanceChartEvent(String message) {
        this.message = message;
    }
}
