package com.field.datamatics.views;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import com.field.datamatics.R;
import com.field.datamatics.interfaces.OperationCallBacks;
import com.field.datamatics.utils.CSVReader;
import com.field.datamatics.utils.PreferenceUtil;

/**
 * Created by anoop on 20/9/15.
 */
public class SplashScreen extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        if(PreferenceUtil.getIntsance().isLogin()){
            startActivity(new Intent(getApplicationContext(),MainActivity.class));
            finish();
        }else{
            //
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    startActivity(new Intent(getApplicationContext(),Login.class));
                    finish();
                }
            }, 1000);
        }
        /*HashMap<String, String> params = new HashMap<String, String>();
        params.put("encription_key", ApiConstants.ENCRYPTION_KEY);
        ApiService.getInstance().makeApiCall(ApiConstants.AppViewProductTextFile, params, new ApiCallbacks() {
            @Override
            public void onSuccess(Object objects) {
                Toast.makeText(getApplicationContext(),"data fetched",Toast.LENGTH_SHORT).show();
                GetCSVProducts getCSVProducts=new Gson().fromJson(objects.toString(),GetCSVProducts.class);
                createFile(getCSVProducts.getBody()[0].getProductstream());
            }

            @Override
            public void onError(Object objects) {
                Toast.makeText(getApplicationContext(),"data fetched failed",Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onErrorMessage(String message) {

            }
        });*/






    }
    private void createFile(String data){
        /*new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(getApplicationContext(),Login.class));
                finish();
            }
        }, 400);*/
        CSVReader.getInstance().addProductsFromCSV(SplashScreen.this,data,"", new OperationCallBacks() {
            @Override
            public void onSuccess() {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        //startService(new Intent(getApplicationContext(), SecondSyncService.class));
                        Toast.makeText(getApplicationContext(), "file created", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(),Login.class));
                        finish();
                    }
                }, 400);
                Toast.makeText(getApplicationContext(), "file created", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onError() {
               // Toast.makeText(getApplicationContext(),"file creacreation failed",Toast.LENGTH_SHORT).show();
                finish();

            }
        });
    }
}
