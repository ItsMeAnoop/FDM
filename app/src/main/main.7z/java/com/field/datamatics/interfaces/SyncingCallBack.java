package com.field.datamatics.interfaces;

/**
 * Created by USER on 1/3/2016.
 */
public interface SyncingCallBack {
    public void onPerecentage(int percentage);
}
