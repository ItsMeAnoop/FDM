package com.field.datamatics.eventbus;

/**
 * Created by Jithz on 12/12/2015.
 */
public class ScoreEvent {
    public final String message;

    public ScoreEvent(String message) {
        this.message = message;
    }
}
