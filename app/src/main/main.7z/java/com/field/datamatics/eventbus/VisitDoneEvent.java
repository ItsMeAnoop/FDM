package com.field.datamatics.eventbus;

/**
 * Created by USER on 12/28/2015.
 */
public class VisitDoneEvent {
    public final String message;

    public VisitDoneEvent(String message) {
        this.message = message;
    }
}
