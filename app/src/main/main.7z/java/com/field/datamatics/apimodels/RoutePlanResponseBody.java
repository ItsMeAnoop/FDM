package com.field.datamatics.apimodels;

/**
 * Created by anoop on 28/10/15.
 */
public class RoutePlanResponseBody
{
    private String routeno;
    private String date;
    private String createddate;
    private String clientno;
    private String prepareduser;
    private String userid;
    private String workcalanderid;
    private String preparedby;
    private String authdate;
    private String authorizedby;
    private String visitype;
    private String customerid;
    private String routplanno;
    private String authuser;
    private String remarks;
    private String status;


    public String getRouteno() {
        return routeno;
    }

    public void setRouteno(String routeno) {
        this.routeno = routeno;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCreateddate() {
        return createddate;
    }

    public void setCreateddate(String createddate) {
        this.createddate = createddate;
    }

    public String getClientno() {
        return clientno;
    }

    public void setClientno(String clientno) {
        this.clientno = clientno;
    }

    public String getPrepareduser() {
        return prepareduser;
    }

    public void setPrepareduser(String prepareduser) {
        this.prepareduser = prepareduser;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getWorkcalanderid() {
        return workcalanderid;
    }

    public void setWorkcalanderid(String workcalanderid) {
        this.workcalanderid = workcalanderid;
    }

    public String getPreparedby() {
        return preparedby;
    }

    public void setPreparedby(String preparedby) {
        this.preparedby = preparedby;
    }

    public String getAuthdate() {
        return authdate;
    }

    public void setAuthdate(String authdate) {
        this.authdate = authdate;
    }

    public String getAuthorizedby() {
        return authorizedby;
    }

    public void setAuthorizedby(String authorizedby) {
        this.authorizedby = authorizedby;
    }

    public String getVisitype() {
        return visitype;
    }

    public void setVisitype(String visitype) {
        this.visitype = visitype;
    }

    public String getCustomerid() {
        return customerid;
    }

    public void setCustomerid(String customerid) {
        this.customerid = customerid;
    }

    public String getRoutplanno() {
        return routplanno;
    }

    public void setRoutplanno(String routplanno) {
        this.routplanno = routplanno;
    }

    public String getAuthuser() {
        return authuser;
    }

    public void setAuthuser(String authuser) {
        this.authuser = authuser;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}