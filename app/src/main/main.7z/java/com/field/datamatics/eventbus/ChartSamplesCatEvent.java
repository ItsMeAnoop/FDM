package com.field.datamatics.eventbus;

/**
 * Created by Jithz on 12/12/2015.
 */
public class ChartSamplesCatEvent {
    public final String[] labels;

    public ChartSamplesCatEvent(String[] labels) {
        this.labels = labels;
    }
}
