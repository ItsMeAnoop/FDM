package com.field.datamatics.eventbus;

/**
 * Created by Jithz on 12/12/2015.
 */
public class TimeSpentEvent {
    public final String message;

    public TimeSpentEvent(String message) {
        this.message = message;
    }
}
