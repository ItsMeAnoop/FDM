package com.field.datamatics.constants;

/**
 * Created by anoop on 20/9/15.
 */
public class ViewConstants {
    /**
     * Progress Dialog Message Constant
     */
    public static final String PLEASE_WAIT="Please wait...";
    public static final String NO_NETWORK="Network not available";

}
