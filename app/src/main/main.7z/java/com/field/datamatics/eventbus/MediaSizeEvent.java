package com.field.datamatics.eventbus;

/**
 * Created by Jithz on 12/12/2015.
 */
public class MediaSizeEvent {
    public final String message;

    public MediaSizeEvent(String message) {
        this.message = message;
    }
}
