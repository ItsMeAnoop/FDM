package com.field.datamatics.Services.appservices;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.Log;
import android.widget.Toast;

import com.field.datamatics.Services.ApiService;
import com.field.datamatics.apimodels.CommonSubmitJson;
import com.field.datamatics.constants.ApiConstants;
import com.field.datamatics.interfaces.ApiCallbacks;
import com.field.datamatics.interfaces.SyncingCallBack;
import com.field.datamatics.synctables.SyncAppLog;
import com.field.datamatics.synctables.SyncAppointment;
import com.field.datamatics.synctables.SyncGeo;
import com.field.datamatics.synctables.SyncMessage;
import com.field.datamatics.synctables.SyncRoutePlan;
import com.field.datamatics.synctables.SyncSurveyDetails;
import com.field.datamatics.synctables.SyncVisitDetails;
import com.google.gson.Gson;
import com.raizlabs.android.dbflow.sql.language.Delete;
import com.raizlabs.android.dbflow.sql.language.Select;

import java.util.ArrayList;

/**
 * Created by anoop on 10/11/15.
 */
public class UpdateSyncService extends Service {
    private Gson gson;
    private ArrayList<SyncAppLog> data;
    private ArrayList<SyncAppointment> app_data;
    private ArrayList<SyncGeo> geo_data;
    private ArrayList<SyncMessage> msg_data;
   // private ArrayList<SyncRoutePlan> route_data;
   // private ArrayList<SyncSurveyDetails> survey_data;
    private ArrayList<SyncVisitDetails> visit_data;
    private static SyncingCallBack callBack;

    public static Intent getIntent(SyncingCallBack call,Activity activity){
        callBack =call;
        return new Intent(activity,UpdateSyncService.class);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        gson=new Gson();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        readAllData();
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    private void readAllData(){
        data= (ArrayList<SyncAppLog>) new Select().from(SyncAppLog.class).queryList();
        app_data= (ArrayList<SyncAppointment>) new Select().from(SyncAppointment.class).queryList();
        geo_data= (ArrayList<SyncGeo>) new Select().from(SyncGeo.class).queryList();
        msg_data=(ArrayList<SyncMessage>) new Select().from(SyncMessage.class).queryList();
        visit_data= (ArrayList<SyncVisitDetails>) new Select().from(SyncVisitDetails.class).queryList();
        //route_data= (ArrayList<SyncRoutePlan>) new Select().from(SyncRoutePlan.class).queryList();
        //survey_data= (ArrayList<SyncSurveyDetails>) new Select().from(SyncSurveyDetails.class).queryList();
        syncAppLog();
    }
    private void syncAppLog(){
        callBack.onPerecentage(0);
        if(data!=null&&data.size()>0){
            CommonSubmitJson commonSubmitJson=gson.fromJson(data.get(0).log_details,CommonSubmitJson.class);
            ApiService.getInstance().makeApiCall(ApiConstants.AppLogDetails, commonSubmitJson, new ApiCallbacks() {
                @Override
                public void onSuccess(Object objects) {
                    data.remove(0);
                    if(data.size()!=0){
                        syncAppLog();
                    }
                    else{
                        //clear db data
                        Delete.table(SyncAppLog.class);
                        syncAppointment();
                    }

                }

                @Override
                public void onError(Object objects) {
                    stopSelf();
                }

                @Override
                public void onErrorMessage(String message) {

                }
            });

        }
        else{
            syncAppointment();
        }

    }
    private void syncAppointment(){
        callBack.onPerecentage(20);
        if(app_data!=null&&app_data.size()>0){
            CommonSubmitJson commonSubmitJson=gson.fromJson(app_data.get(0).appointment_details,CommonSubmitJson.class);
            ApiService.getInstance().makeApiCall(ApiConstants.AppAppointmentDetails, commonSubmitJson, new ApiCallbacks() {
                @Override
                public void onSuccess(Object objects) {
                    app_data.remove(0);
                    if(app_data.size()!=0){
                        syncAppointment();
                    }
                    else{
                        //clear db data
                        Delete.table(SyncAppointment.class);
                        syncGeo();
                    }


                }

                @Override
                public void onError(Object objects) {
                    stopSelf();
                }

                @Override
                public void onErrorMessage(String message) {

                }
            });

        }
        else{
            syncGeo();
        }

    }

    private void syncGeo(){
        callBack.onPerecentage(40);
        if(geo_data!=null&&geo_data.size()>0){
            CommonSubmitJson commonSubmitJson=gson.fromJson(geo_data.get(0).geo_details,CommonSubmitJson.class);
            ApiService.getInstance().makeApiCall(ApiConstants.GeocordinatedUpdat, commonSubmitJson, new ApiCallbacks() {
                @Override
                public void onSuccess(Object objects) {
                    geo_data.remove(0);
                    if(geo_data.size()!=0){
                        syncGeo();
                    }
                    else{
                        //clear data
                        Delete.table(SyncGeo.class);
                        syncMessages();
                    }


                }

                @Override
                public void onError(Object objects) {
                    stopSelf();
                }

                @Override
                public void onErrorMessage(String message) {

                }
            });

        }
        else{
            syncMessages();

        }

    }
    private void syncMessages(){
        callBack.onPerecentage(60);
        if(msg_data!=null&&msg_data.size()>0){
            CommonSubmitJson commonSubmitJson=gson.fromJson(msg_data.get(0).message_details,CommonSubmitJson.class);
            ApiService.getInstance().makeApiCall(ApiConstants.AppMessageDetails, commonSubmitJson, new ApiCallbacks() {
                @Override
                public void onSuccess(Object objects) {
                    msg_data.remove(0);
                    if(msg_data.size()!=0){
                        syncMessages();
                    }
                    else{
                        //clear data
                        Delete.table(SyncMessage.class);
                        syncVisitDetails();
                    }


                }

                @Override
                public void onError(Object objects) {
                    stopSelf();
                }

                @Override
                public void onErrorMessage(String message) {

                }
            });

        }
        else{
            syncVisitDetails();
        }
    }
    private void syncVisitDetails(){
        callBack.onPerecentage(80);
        if(visit_data!=null&&visit_data.size()>0){
            CommonSubmitJson commonSubmitJson=gson.fromJson(visit_data.get(0).visit_details,CommonSubmitJson.class);
            ApiService.getInstance().makeApiCall(ApiConstants.AppvisitedDetails, commonSubmitJson, new ApiCallbacks() {
                @Override
                public void onSuccess(Object objects) {
                    visit_data.remove(0);
                    if(visit_data.size()!=0){
                        syncVisitDetails();
                    }
                    else{
                        //clear data
                        Delete.table(SyncVisitDetails.class);
                        callBack.onPerecentage(100);
                        stopSelf();
                    }


                }

                @Override
                public void onError(Object objects) {
                    callBack.onPerecentage(100);
                    stopSelf();

                }

                @Override
                public void onErrorMessage(String message) {

                }
            });

        }
        else{
            callBack.onPerecentage(100);
            stopSelf();
        }
    }

    private void nextSchedule(){
        try {

            //Create a new PendingIntent and add it to the AlarmManager
            Intent intent = new Intent(getApplicationContext(), UpdateSyncService.class);
            PendingIntent pendingIntent = PendingIntent.getService(getApplicationContext(),
                    12345, intent, PendingIntent.FLAG_CANCEL_CURRENT);
            AlarmManager am =
                    (AlarmManager)getSystemService(Activity.ALARM_SERVICE);
            am.setRepeating(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime(),
                    2*60*60,pendingIntent);

        } catch (Exception e) {}
    }

}
























    /* private void syncRoutePlan(){
        if(route_data!=null&&route_data.size()>0){
            CommonSubmitJson commonSubmitJson=gson.fromJson(route_data.get(0).route_plan_details,CommonSubmitJson.class);
            Log.d("Data",route_data.get(0).route_plan_details);
            Toast.makeText(getApplicationContext(),route_data.get(0).route_plan_details,Toast.LENGTH_LONG).show();
            ApiService.getInstance().makeApiCall(ApiConstants.AppRoutePlanDetails, commonSubmitJson, new ApiCallbacks() {
                @Override
                public void onSuccess(Object objects) {
                    route_data.remove(0);
                    if(route_data.size()!=0){
                        syncRoutePlan();
                    }
                    else{
                        //clear data
                        Delete.table(SyncRoutePlan.class);
                        syncSurveyDetails();
                    }


                }

                @Override
                public void onError(Object objects) {

                }

                @Override
                public void onErrorMessage(String message) {

                }
            });

        }
        else{
            syncSurveyDetails();
        }

    }
    private void syncSurveyDetails(){
        if(survey_data!=null&&survey_data.size()>0){
            CommonSubmitJson commonSubmitJson=gson.fromJson(survey_data.get(0).survey_details,CommonSubmitJson.class);
            ApiService.getInstance().makeApiCall(ApiConstants.AppSurveyDetails, commonSubmitJson, new ApiCallbacks() {
                @Override
                public void onSuccess(Object objects) {
                    survey_data.remove(0);
                    if(survey_data.size()!=0){
                        syncSurveyDetails();
                    }
                    else{
                        //clear data
                        Delete.table(SyncSurveyDetails.class);
                        syncVisitDetails();
                    }


                }

                @Override
                public void onError(Object objects) {

                }

                @Override
                public void onErrorMessage(String message) {

                }
            });

        }
        else{
            syncVisitDetails();
        }

    }*/








